# rays_pycocotools

Wrapper of [pycocotools](https://github.com/cocodataset/cocoapi) that correctly installs with pip.